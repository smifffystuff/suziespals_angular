module.exports = {
  host: 'suziespals-instance.cxveiegb4bha.us-east-1.rds.amazonaws.com',
  user: 'martinsmifff',
  password: 'Su5an0518',
  database: 'suziespals'
};
